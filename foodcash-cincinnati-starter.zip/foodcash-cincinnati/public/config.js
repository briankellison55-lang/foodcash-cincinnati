// Replace these placeholders with your Supabase Project URL and anon/publishable key.
// NEVER use the Supabase service_role secret in browser code.
window.FOODCASH_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR-SUPABASE-ANON-OR-PUBLISHABLE-KEY"
};
