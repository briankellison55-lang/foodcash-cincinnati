(() => {
 const cfg=window.FOODCASH_CONFIG||{};
 const configured=cfg.SUPABASE_URL?.startsWith('https://')&&cfg.SUPABASE_ANON_KEY&&!cfg.SUPABASE_ANON_KEY.startsWith('YOUR-');
 const $=id=>document.getElementById(id);
 let db=null,user=null,isAdmin=false,restaurants=[];
 const say=(id,msg)=>$(id).textContent=msg;
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 async function init(){
  if(!configured||!window.supabase){$('restaurants').innerHTML='<div class="card"><h3>Setup required</h3><p>FoodCash is ready for its Supabase connection. Follow the README and add your project URL and anon key in public/config.js.</p></div>';return}
  db=window.supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY);
  await loadRestaurants();
  const {data:{session}}=await db.auth.getSession();if(session){user=session.user;await checkAdmin()}
  db.auth.onAuthStateChange(async(_event,session)=>{user=session?.user||null;if(user)await checkAdmin();else{isAdmin=false;$('admin').classList.add('hidden')}});
  const params=new URLSearchParams(location.search),code=params.get('ref');
  if(code){const {data,error}=await db.rpc('record_referral_click',{p_code:code});if(!error&&data){location.replace(data);return}}
 }
 async function loadRestaurants(){
  const {data,error}=await db.from('restaurants').select('id,name,city,ordering_url,referral_code').eq('is_active',true).order('name');
  if(error){$('restaurants').innerHTML='<div class="card"><p>Could not load restaurants. Check your Supabase setup.</p></div>';return}
  restaurants=data||[];
  $('restaurants').innerHTML=restaurants.length?restaurants.map(x=>`<article class="card"><h3>${esc(x.name)}</h3><p>${esc(x.city)}</p><a href="?ref=${encodeURIComponent(x.referral_code)}">Order from restaurant</a></article>`).join(''):'<div class="card"><h3>Coming soon</h3><p>FoodCash is recruiting Cincinnati restaurant partners. Check back soon.</p></div>';
  $('o-restaurant').innerHTML='<option value="">Choose restaurant</option>'+restaurants.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join('');
 }
 async function checkAdmin(){
  const {data,error}=await db.from('profiles').select('role').eq('id',user.id).maybeSingle();
  isAdmin=!error&&data?.role==='admin';
  $('admin').classList.toggle('hidden',!isAdmin);
  $('admin-status').textContent=isAdmin?'Signed in as administrator: '+user.email:'Signed in, but this account is not an administrator.';
  if(isAdmin)await loadOrders();
 }
 $('login-open').onclick=()=>$('auth-panel').classList.remove('hidden');
 $('login-close').onclick=()=>$('auth-panel').classList.add('hidden');
 $('refresh').onclick=loadRestaurants;
 $('login-form').onsubmit=async e=>{e.preventDefault();if(!db)return;const {error}=await db.auth.signInWithPassword({email:$('email').value,password:$('password').value});say('login-message',error?error.message:'Signed in.');};
 $('logout').onclick=async()=>{await db.auth.signOut();user=null;isAdmin=false;$('admin').classList.add('hidden')};
 $('restaurant-form').onsubmit=async e=>{
  e.preventDefault();if(!isAdmin)return;
  const row={name:$('r-name').value.trim(),city:$('r-city').value.trim(),ordering_url:$('r-url').value.trim(),referral_code:$('r-code').value.trim(),commission_rate:Number($('r-rate').value),is_active:$('r-active').checked};
  const {error}=await db.from('restaurants').insert(row);
  say('restaurant-message',error?error.message:'Restaurant saved. Only mark active after the agreement is signed.');
  if(!error){e.target.reset();$('r-city').value='Cincinnati, OH';$('r-rate').value='10';await loadRestaurants()}
 };
 $('order-form').onsubmit=async e=>{
  e.preventDefault();if(!isAdmin)return;
  const restaurant=restaurants.find(x=>x.id===$('o-restaurant').value);
  const subtotal=Number($('o-subtotal').value),rate=Number($('o-rate').value);
  if(!restaurant||subtotal<=0||rate<0||rate>100)return;
  const {error}=await db.from('orders').insert({restaurant_id:restaurant.id,external_order_ref:$('o-ref').value.trim(),eligible_subtotal:subtotal,commission_rate:rate,status:$('o-status').value,verification_note:'Entered by administrator; retain restaurant confirmation evidence.'});
  say('order-message',error?error.message:'Order recorded.');
  if(!error){e.target.reset();await loadOrders()}
 };
 async function loadOrders(){
  const {data,error}=await db.from('orders').select('id,external_order_ref,eligible_subtotal,commission_rate,commission_amount,status,restaurants(name)').order('created_at',{ascending:false});
  if(error){$('orders').textContent=error.message;return}
  $('orders').innerHTML=data?.length?'<table><thead><tr><th>Restaurant / Ref</th><th>Subtotal</th><th>Rate</th><th>Commission</th><th>Status</th></tr></thead><tbody>'+data.map(o=>`<tr><td>${esc(o.restaurants?.name)}<br>${esc(o.external_order_ref)}</td><td>$${Number(o.eligible_subtotal).toFixed(2)}</td><td>${o.commission_rate}%</td><td>$${Number(o.commission_amount).toFixed(2)}</td><td>${esc(o.status)}</td></tr>`).join('')+'</tbody></table>':'<p class="muted">No orders yet.</p>';
  $('p-order').innerHTML='<option value="">Choose approved / payable order</option>'+(data||[]).filter(o=>o.status==='payable').map(o=>`<option value="${o.id}">${esc(o.external_order_ref)} — $${Number(o.commission_amount).toFixed(2)}</option>`).join('');
 }
 $('load-orders').onclick=loadOrders;
 $('payout-form').onsubmit=async e=>{
  e.preventDefault();if(!isAdmin)return;
  const orderId=$('p-order').value,amount=Number($('p-amount').value),ref=$('p-ref').value.trim();
  if(!orderId||amount<=0||!ref)return;
  const {data:order,error:readError}=await db.from('orders').select('commission_amount,status').eq('id',orderId).single();
  if(readError||!order||order.status!=='payable'||Math.abs(Number(order.commission_amount)-amount)>0.009){say('payout-message','Choose a payable order and enter its exact outstanding commission amount.');return}
  const {error}=await db.from('payouts').insert({order_id:orderId,amount,payment_method:'Cash App (manual)',payment_reference:ref,status:'recorded'});
  if(!error) await db.from('orders').update({status:'paid'}).eq('id',orderId);
  say('payout-message',error?error.message:'Payout record saved and order marked paid. This app did not send money.');
  if(!error){e.target.reset();await loadOrders()}
 };
 init();
})();
