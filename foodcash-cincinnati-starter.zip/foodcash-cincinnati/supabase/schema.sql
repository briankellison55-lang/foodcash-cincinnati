-- FoodCash Cincinnati starter schema.
-- Run in Supabase SQL Editor. Review before production use.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, role) values (new.id, 'customer')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_foodcash_admin()
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists(select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin');
$$;

create table if not exists public.restaurants (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  city text not null default 'Cincinnati, OH',
  ordering_url text not null,
  referral_code text not null unique,
  commission_rate numeric(5,2) not null check (commission_rate >= 0 and commission_rate <= 100),
  is_active boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.referral_clicks (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id),
  clicked_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id),
  external_order_ref text not null,
  eligible_subtotal numeric(12,2) not null check (eligible_subtotal > 0),
  commission_rate numeric(5,2) not null check (commission_rate >= 0 and commission_rate <= 100),
  commission_amount numeric(12,2) generated always as (round(eligible_subtotal * commission_rate / 100, 2)) stored,
  status text not null default 'pending' check (status in ('pending','approved','payable','paid','rejected')),
  verification_note text,
  created_at timestamptz not null default now(),
  unique (restaurant_id, external_order_ref)
);

create table if not exists public.payouts (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id),
  amount numeric(12,2) not null check (amount > 0),
  payment_method text not null,
  payment_reference text not null,
  status text not null default 'recorded' check (status in ('recorded','confirmed','reversed')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.restaurants enable row level security;
alter table public.referral_clicks enable row level security;
alter table public.orders enable row level security;
alter table public.payouts enable row level security;

drop policy if exists "Users read own profile" on public.profiles;
create policy "Users read own profile" on public.profiles for select to authenticated using (id = auth.uid() or public.is_foodcash_admin());
drop policy if exists "Admins manage profiles" on public.profiles;
create policy "Admins manage profiles" on public.profiles for update to authenticated using (public.is_foodcash_admin()) with check (public.is_foodcash_admin());

drop policy if exists "Public read active restaurants" on public.restaurants;
create policy "Public read active restaurants" on public.restaurants for select to anon, authenticated using (is_active = true or public.is_foodcash_admin());
drop policy if exists "Admins manage restaurants" on public.restaurants;
create policy "Admins manage restaurants" on public.restaurants for all to authenticated using (public.is_foodcash_admin()) with check (public.is_foodcash_admin());

drop policy if exists "Admins read referral clicks" on public.referral_clicks;
create policy "Admins read referral clicks" on public.referral_clicks for select to authenticated using (public.is_foodcash_admin());

drop policy if exists "Admins manage orders" on public.orders;
create policy "Admins manage orders" on public.orders for all to authenticated using (public.is_foodcash_admin()) with check (public.is_foodcash_admin());

drop policy if exists "Admins manage payouts" on public.payouts;
create policy "Admins manage payouts" on public.payouts for all to authenticated using (public.is_foodcash_admin()) with check (public.is_foodcash_admin());

create or replace function public.record_referral_click(p_code text)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare destination text; rid uuid;
begin
  select id, ordering_url into rid, destination
  from public.restaurants
  where referral_code = p_code and is_active = true;
  if rid is null then return null; end if;
  insert into public.referral_clicks (restaurant_id) values (rid);
  return destination;
end;
$$;

revoke all on function public.record_referral_click(text) from public;
grant execute on function public.record_referral_click(text) to anon, authenticated;

grant usage on schema public to anon, authenticated;
grant select on public.restaurants to anon, authenticated;
grant select, update on public.profiles to authenticated;
grant select on public.referral_clicks to authenticated;
grant select, insert, update, delete on public.orders to authenticated;
grant select, insert, update, delete on public.payouts to authenticated;
grant insert, update, delete on public.restaurants to authenticated;

-- After creating your own Supabase Auth user, promote only your own account:
-- update public.profiles
-- set role = 'admin'
-- where id = (select id from auth.users where email = 'YOUR-LOGIN-EMAIL');
